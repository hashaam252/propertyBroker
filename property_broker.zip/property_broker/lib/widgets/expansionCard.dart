import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:property_broker/utils/colors.dart';
import 'package:property_broker/utils/textstyle.dart';
import 'package:property_broker/widgets/custombutton.dart';

class ExpansionCard extends StatefulWidget {
  bool staff = false;
  ExpansionCard({@required this.staff});
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _card();
  }
}

class _card extends State<ExpansionCard> {
  var width, height;
  bool val = false;
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    width = MediaQuery.of(context).size.width;
    height = MediaQuery.of(context).size.height;
    return Container(
      width: width * .85,
      color: Colors.white,
      child: ExpansionTile(
        trailing: Icon(
          val == true ? Icons.arrow_drop_down_sharp : Icons.arrow_right,
          color: Colors.grey,
        ),
        onExpansionChanged: (value) {
          setState(() {
            value = !value;
            val = !val;
          });
        },
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "Abdul Jabbar",
              style: headingStyle.copyWith(
                  fontWeight: FontWeight.w600,
                  color: Colors.black,
                  fontSize: height * .02),
            ),
            Text(
              "31256985",
              style: headingStyle.copyWith(
                  fontWeight: FontWeight.w600,
                  color: Colors.grey,
                  fontSize: height * .015),
            ),
            Text(
              "Qatar",
              style: headingStyle.copyWith(
                  fontWeight: FontWeight.w600,
                  color: Colors.grey,
                  fontSize: height * .015),
            ),
          ],
        ),
        children: [
          Padding(
            padding: EdgeInsets.only(
                bottom: height * .01, left: width * .04, right: width * .04),
            child: Column(
              children: [
                Row(
                  children: [
                    Text(
                      "jabbar@gmail.com",
                      style: headingStyle.copyWith(
                          color: Colors.black, fontSize: height * .015),
                    ),
                  ],
                ),
                SizedBox(
                  height: height * .02,
                ),
                Row(
                  children: [
                    Text(
                      "Doha Qatar",
                      style: headingStyle.copyWith(
                          color: Colors.black, fontSize: height * .015),
                    ),
                  ],
                ),
                SizedBox(
                  height: height * .02,
                ),
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        "Call Back Request to Discuss More About This Property...",
                        style: headingStyle.copyWith(
                            color: Colors.black, fontSize: height * .015),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: height * .02,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    widget.staff == true
                        ? Card(
                            color: white,
                            elevation: 5,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(
                                  MediaQuery.of(context).size.width * .02),
                            ),
                            child: Container(
                                width: width * .4,
                                height: height * .06,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(
                                        MediaQuery.of(context).size.width *
                                            .02),
                                    color: white,
                                    border: Border.all(color: white)),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Icon(
                                          FontAwesomeIcons.edit,
                                          color: mainColor,
                                          size: 20,
                                        ),
                                        SizedBox(
                                          width: width * .015,
                                        ),
                                        Text(
                                          "Edit",
                                          style: headingStyle.copyWith(
                                              color: mainColor,
                                              fontSize: 16,
                                              fontWeight: FontWeight.w600),
                                        ),
                                      ],
                                    ),
                                  ],
                                )),
                          )
                        : GestureDetector(
                            onTap: () {},
                            child: CustomButton(
                              width: width * .4,
                              height: height * .06,
                              textColor: mainColor,
                              color: Colors.white,
                              title: "View Property",
                            ),
                          ),
                  ],
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
