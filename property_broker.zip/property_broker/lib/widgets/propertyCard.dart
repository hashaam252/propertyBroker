import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:property_broker/utils/colors.dart';
import 'package:property_broker/utils/textstyle.dart';

class PropertyCard extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _PropertyCard();
  }
}

class _PropertyCard extends State<PropertyCard> {
  var width, height;
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    width = MediaQuery.of(context).size.width;
    height = MediaQuery.of(context).size.height;
    return InkWell(
      onTap: () {},
      child: Container(
        margin: EdgeInsets.only(bottom: height * .02),
        width: width * .9,
        // padding: EdgeInsets.all(wid),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: width * .9,
                  height: height * .2,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(width * .03),
                      image: DecorationImage(
                          image: AssetImage(
                            "images/property.jpg",
                          ),
                          colorFilter: new ColorFilter.mode(
                              Colors.black.withOpacity(0.4), BlendMode.darken),
                          fit: BoxFit.fill)),
                  padding: EdgeInsets.all(width * .02),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Container(
                            width: width * .25,
                            height: height * .04,
                            decoration: BoxDecoration(
                                borderRadius:
                                    BorderRadius.circular(width * .02),
                                color: white),
                            child: Center(
                              child: Text(
                                "Published",
                                style: headingStyle.copyWith(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: mainColor),
                              ),
                            ),
                          )
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "2 Bedroom Flat in Mercato Palazzo for rent",
                            maxLines: 1,
                            style: headingStyle.copyWith(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: white),
                          )
                        ],
                      ),
                    ],
                  ),
                )
              ],
            ),
            SizedBox(
              height: height * .02,
            ),
            Padding(
              padding: EdgeInsets.only(left: width * .04, right: width * .04),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "11000 QAR",
                    style: headingStyle.copyWith(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: mainColor),
                  ),
                  InkWell(
                    splashColor: white,
                    child: Container(
                      width: width * .2,
                      height: height * .04,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(width * .02),
                          color: mainColor),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                "Edit",
                                style: headingStyle.copyWith(
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                    color: white),
                              ),
                              SizedBox(
                                width: width * .025,
                              ),
                              Icon(
                                FontAwesomeIcons.edit,
                                color: white,
                                size: height * .02,
                              )
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
                padding: EdgeInsets.only(
                    left: width * .04, top: height * .015, right: width * .04),
                child: bottomOptions("S.no#1", "Code: 10028", "10/01/2022",
                    "Views:5", "Leads:0")),
          ],
        ),
      ),
    );
  }

  Widget bottomOptions(serial, code, date, views, lead) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Text(
          "$serial",
          style: headingStyle.copyWith(
              fontSize: height * .015, color: Colors.grey),
        ),
        Text(
          "$code",
          style: headingStyle.copyWith(
              fontSize: height * .015, color: Colors.grey),
        ),
        Text(
          "$date",
          style: headingStyle.copyWith(
              fontSize: height * .015, color: Colors.grey),
        ),
        Text(
          "$views",
          style: headingStyle.copyWith(
              fontSize: height * .015, color: Colors.grey),
        ),
        Text(
          "$lead",
          style: headingStyle.copyWith(
              fontSize: height * .015, color: Colors.grey),
        ),
      ],
    );
  }
}
