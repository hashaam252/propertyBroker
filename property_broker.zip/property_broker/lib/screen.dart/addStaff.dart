import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:property_broker/utils/colors.dart';
import 'package:property_broker/utils/routes.dart';
import 'package:property_broker/utils/textstyle.dart';
import 'package:property_broker/widgets/customAppbar.dart';
import 'package:property_broker/widgets/custombutton.dart';
import 'package:property_broker/widgets/customdrawer.dart';
import 'package:property_broker/widgets/customtextfield.dart';

class AddStaff extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _ContactRequest();
  }
}

class _ContactRequest extends State<AddStaff> {
  var width, height;
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  List<String> type = [
    "hello",
    "world",
  ];
  @override
  Widget build(BuildContext context) {
    width = MediaQuery.of(context).size.width;
    height = MediaQuery.of(context).size.height;
    // TODO: implement build
    return Scaffold(
      backgroundColor: white,
      key: scaffoldKey,
      appBar: CustomAppBar(
        height: height * .08,
        title: "Add Staff",
        appointment: false,
        support: false,
        width: width,
        home: true,
      ),
      drawer: BuyerDrawer(),
      body: Container(
        width: width,
        height: height,
        padding: EdgeInsets.all(width * .03),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomTextField(
                    email: false,
                    phone: false,
                    whatapp: false,
                    // controller: confirmPassword,
                    width: width * .85,
                    pass: false,
                    keyboardTypenumeric: false,
                    number: false,
                    title: "Name*",
                    height: height * .06,
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomTextField(
                    email: false,
                    phone: true,
                    whatapp: false,
                    // controller: confirmPassword,
                    width: width * .85,
                    pass: false,
                    keyboardTypenumeric: false,
                    number: false,
                    title: "Phone*",
                    height: height * .06,
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomTextField(
                    email: false,
                    phone: true,
                    whatapp: false,
                    // controller: confirmPassword,
                    width: width * .85,
                    pass: false,
                    keyboardTypenumeric: false,
                    number: false,
                    title: "Whatsapp Number*",
                    height: height * .06,
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomTextField(
                    email: true,
                    phone: false,
                    whatapp: false,
                    // controller: confirmPassword,
                    width: width * .85,
                    pass: false,
                    keyboardTypenumeric: false,
                    number: false,
                    title: "Email*",
                    height: height * .06,
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomTextField(
                    email: false,
                    phone: false,
                    whatapp: false,
                    // controller: confirmPassword,
                    width: width * .85,
                    pass: true,
                    keyboardTypenumeric: false,
                    number: false,
                    title: "Password*",
                    height: height * .06,
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    // margin: EdgeInsets.only(top: height * .02),
                    width: width * .85,
                    height: height * .06,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(
                          MediaQuery.of(context).size.width * .02),
                      color: Colors.white,
                      border: Border.all(color: Colors.grey[200]),
                    ),
                    padding: EdgeInsets.only(
                        left: MediaQuery.of(context).size.width * .03,
                        right: MediaQuery.of(context).size.width * .02),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton(
                        isExpanded: true,
                        iconEnabledColor: mainColor,
                        hint: Text("Select Staff Type*"),
                        items: type.map((item) {
                          return new DropdownMenuItem(
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Text("$item"),
                              ],
                            ),
                            value: item,
                          );
                        }).toList(),
                        onChanged: (newVal) {
                          // print(_propertyTypeSelected);
                        },
                        // value: ,
                        dropdownColor: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                    splashColor: lightmainColor,
                    onTap: () {
                      // AppRoutes.push(context, HomeScreen());
                    },
                    child: CustomButton(
                      width: width * .85,
                      height: height * .06,
                      color: mainColor,
                      textColor: Colors.white,
                      title: "Publish",
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: height * .02,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                    splashColor: lightmainColor,
                    onTap: () {
                      AppRoutes.pop(context);
                      // AppRoutes.push(context, HomeScreen());
                    },
                    child: CustomButton(
                      width: width * .85,
                      height: height * .06,
                      color: white,
                      textColor: mainColor,
                      title: "Cancel",
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
