import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:property_broker/utils/colors.dart';
import 'package:property_broker/utils/textstyle.dart';
import 'package:property_broker/widgets/customAppbar.dart';
import 'package:property_broker/widgets/customdrawer.dart';
import 'package:property_broker/widgets/customtextfield.dart';

class SupportContact extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _ContactRequest();
  }
}

class _ContactRequest extends State<SupportContact> {
  var width, height;
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    width = MediaQuery.of(context).size.width;
    height = MediaQuery.of(context).size.height;
    // TODO: implement build
    return Scaffold(
      backgroundColor: white,
      key: scaffoldKey,
      drawer: BuyerDrawer(),
      appBar: CustomAppBar(
        height: height * .08,
        title: "Support Contact",
        appointment: false,
        support: true,
        width: width,
        home: false,
      ),
      body: Container(
        width: width,
        height: height,
        padding: EdgeInsets.all(width * .03),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: width * .5,
                    height: height * .17,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(color: Colors.grey, spreadRadius: 0.2)
                        ],
                        color: Colors.white),
                    child: Center(
                      child: Image.asset("images/support.png",
                          width: width * .4,
                          height: height * .1,
                          fit: BoxFit.contain),
                    ),
                  )
                ],
              ),
              SizedBox(
                height: height * .04,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "M Nabhan",
                    style: headingStyle.copyWith(
                        fontWeight: FontWeight.w600,
                        color: Colors.black,
                        fontSize: height * .025),
                  ),
                ],
              ),
              SizedBox(
                height: height * .08,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomTextField(
                    // controller: confirmPassword,
                    email: true,
                    phone: false,
                    whatapp: false,
                    width: width * .85,
                    pass: false,
                    keyboardTypenumeric: false,
                    number: false,
                    title: "support@futureproperty.qa",
                    height: height * .06,
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomTextField(
                    // controller: confirmPassword,
                    email: false,
                    phone: true,
                    whatapp: false,
                    width: width * .85,
                    pass: false,
                    keyboardTypenumeric: false,
                    number: false,
                    title: "+974440010080",
                    height: height * .06,
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomTextField(
                    // controller: confirmPassword,
                    email: false,
                    phone: false,
                    whatapp: true,
                    width: width * .85,
                    pass: false,
                    keyboardTypenumeric: false,
                    number: false,
                    title: "+974440010080",
                    height: height * .06,
                  ),
                ],
              ),
              SizedBox(
                height: height * .02,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
