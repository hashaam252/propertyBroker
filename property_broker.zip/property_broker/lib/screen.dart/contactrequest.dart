import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:property_broker/utils/colors.dart';
import 'package:property_broker/utils/textstyle.dart';
import 'package:property_broker/widgets/customAppbar.dart';
import 'package:property_broker/widgets/custombutton.dart';
import 'package:property_broker/widgets/customdrawer.dart';
import 'package:property_broker/widgets/expansionCard.dart';

class ContactRequest extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _ContactRequest();
  }
}

class _ContactRequest extends State<ContactRequest> {
  var width, height;

  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    width = MediaQuery.of(context).size.width;
    height = MediaQuery.of(context).size.height;
    // TODO: implement build
    return Scaffold(
      backgroundColor: white,
      key: scaffoldKey,
      drawer: BuyerDrawer(),
      appBar: CustomAppBar(
        height: height * .08,
        title: "Contact Request",
        appointment: true,
        support: false,
        width: width,
        home: false,
      ),
      body: Container(
        width: width,
        height: height,
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(itemBuilder: (context, int index) {
                return ExpansionCard(
                  staff: false,
                );
              }),
            )
          ],
        ),
      ),
    );
  }
}
