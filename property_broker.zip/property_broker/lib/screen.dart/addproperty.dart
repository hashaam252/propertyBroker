import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:property_broker/utils/colors.dart';
import 'package:property_broker/utils/textstyle.dart';
import 'package:property_broker/widgets/customAppbar.dart';
import 'package:property_broker/widgets/custombutton.dart';
import 'package:property_broker/widgets/customdrawer.dart';
import 'package:property_broker/widgets/customtextfield.dart';
import 'package:property_broker/widgets/propertytextfield.dart';

class AddProperty extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _ContactRequest();
  }
}

class _ContactRequest extends State<AddProperty> {
  var width, height;
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  List<String> type = [
    "hello",
    "world",
  ];
  List<String> type1 = [
    "hello",
    "world",
  ];
  @override
  Widget build(BuildContext context) {
    width = MediaQuery.of(context).size.width;
    height = MediaQuery.of(context).size.height;
    // TODO: implement build
    return Scaffold(
      backgroundColor: white,
      key: scaffoldKey,
      appBar: CustomAppBar(
        height: height * .08,
        title: "Add Property",
        appointment: false,
        support: false,
        width: width,
        home: true,
      ),
      drawer: BuyerDrawer(),
      body: Container(
        width: width,
        // height: height,
        padding: EdgeInsets.all(width * .03),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                height: height * .03,
              ),
              header(),
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    // margin: EdgeInsets.only(top: height * .02),
                    width: width * .9,
                    height: height * .06,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(
                          MediaQuery.of(context).size.width * .02),
                      color: Colors.white,
                      border: Border.all(color: Colors.grey[200]),
                    ),
                    padding: EdgeInsets.only(
                        left: MediaQuery.of(context).size.width * .03,
                        right: MediaQuery.of(context).size.width * .02),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton(
                        isExpanded: true,
                        iconEnabledColor: mainColor,
                        hint: Row(
                          children: [
                            Text("Select Listing Type"),
                            Text(
                              "*",
                              style: headingStyle.copyWith(color: Colors.red),
                            )
                          ],
                        ),
                        items: type.map((item) {
                          return new DropdownMenuItem(
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Text("$item"),
                              ],
                            ),
                            value: item,
                          );
                        }).toList(),
                        onChanged: (newVal) {
                          // print(_propertyTypeSelected);
                        },
                        // value: ,
                        dropdownColor: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    // margin: EdgeInsets.only(top: height * .02),
                    width: width * .9,
                    height: height * .06,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(
                          MediaQuery.of(context).size.width * .02),
                      color: Colors.white,
                      border: Border.all(color: Colors.grey[200]),
                    ),
                    padding: EdgeInsets.only(
                        left: MediaQuery.of(context).size.width * .03,
                        right: MediaQuery.of(context).size.width * .02),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton(
                        isExpanded: true,
                        iconEnabledColor: mainColor,
                        hint: Row(
                          children: [
                            Text("Select Property Type"),
                            Text(
                              "*",
                              style: headingStyle.copyWith(color: Colors.red),
                            )
                          ],
                        ),
                        items: type1.map((item) {
                          return new DropdownMenuItem(
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Text("$item"),
                              ],
                            ),
                            value: item,
                          );
                        }).toList(),
                        onChanged: (newVal) {
                          // print(_propertyTypeSelected);
                        },
                        // value: ,
                        dropdownColor: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  PropertyTextField(
                    // controller: confirmPassword,
                    width: width * .9,
                    description: false,
                    keyboardTypenumeric: false,
                    number: false,
                    title: "Title*",
                    height: height * .06,
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  PropertyTextField(
                    description: false,
                    // controller: confirmPassword,
                    width: width * .9,

                    keyboardTypenumeric: false,
                    number: false,
                    title: "Title Arabic*",
                    height: height * .06,
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  PropertyTextField(
                    // controller: confirmPassword,
                    width: width * .9,
                    description: true,
                    keyboardTypenumeric: false,
                    number: false,
                    title: "Description*",
                    height: height * .15,
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  PropertyTextField(
                    // controller: confirmPassword,
                    width: width * .9,
                    description: true,
                    keyboardTypenumeric: false,
                    number: false,
                    title: "Description Arabic*",
                    height: height * .15,
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  PropertyTextField(
                    description: false,
                    // controller: confirmPassword,
                    width: width * .9,

                    keyboardTypenumeric: true,
                    number: false,
                    title: "Price*",
                    height: height * .06,
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  PropertyTextField(
                    description: false,
                    // controller: confirmPassword,
                    width: width * .9,

                    keyboardTypenumeric: true,
                    number: false,
                    title: "Area*",
                    height: height * .06,
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  PropertyTextField(
                    description: false,
                    // controller: confirmPassword,
                    width: width * .9,

                    keyboardTypenumeric: false,
                    number: false,
                    title: "Location*",
                    height: height * .06,
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                    splashColor: lightmainColor,
                    onTap: () {
                      // AppRoutes.push(context, HomeScreen());
                    },
                    child: CustomButton(
                      width: width * .9,
                      height: height * .06,
                      color: mainColor,
                      textColor: Colors.white,
                      title: "Submit",
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget header() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: width * .93,
          height: height * .12,
          padding: EdgeInsets.all(width * .03),
          child: Column(
            children: [
              Row(
                children: [
                  Text(
                    "Account Status",
                    style: headingStyle.copyWith(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black),
                  ),
                ],
              ),
              SizedBox(
                height: height * .02,
              ),
              Row(
                // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Subscription Status: Active",
                    maxLines: 1,
                    style: headingStyle.copyWith(
                        fontWeight: FontWeight.w600,
                        color: Colors.grey,
                        fontSize: height * .012),
                  ),
                  Container(
                    margin: EdgeInsets.only(
                        left: width * .005, right: width * .005),
                    color: Colors.grey,
                    height: height * .02,
                    width: 1,
                  ),
                  Text(
                    "Active Properties: 20",
                    maxLines: 1,
                    style: headingStyle.copyWith(
                        fontWeight: FontWeight.w600,
                        color: Colors.grey,
                        fontSize: height * .012),
                  ),
                  Container(
                    margin: EdgeInsets.only(
                        left: width * .005, right: width * .005),
                    color: Colors.grey,
                    height: height * .02,
                    width: 1,
                  ),
                  Text(
                    "Featured Properties: 13",
                    maxLines: 1,
                    style: headingStyle.copyWith(
                        fontWeight: FontWeight.w600,
                        color: Colors.grey,
                        fontSize: height * .012),
                  ),
                ],
              ),
            ],
          ),
        )
      ],
    );
  }
}
