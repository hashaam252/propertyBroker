import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:property_broker/utils/colors.dart';
import 'package:property_broker/utils/textstyle.dart';
import 'package:property_broker/widgets/customAppbar.dart';
import 'package:property_broker/widgets/customdrawer.dart';
import 'package:property_broker/widgets/propertyCard.dart';

class HomeScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _HomeScreen();
  }
}

class _HomeScreen extends State<HomeScreen> {
  var width, height;
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    width = MediaQuery.of(context).size.width;
    height = MediaQuery.of(context).size.height;
    return Scaffold(
      key: scaffoldKey,
      drawer: BuyerDrawer(),
      backgroundColor: white,
      appBar: CustomAppBar(
        height: height * .08,
        title: "Properties",
        home: true,
        appointment: false,
        support: false,
        width: width,
      ),
      body: Container(
        width: width,
        height: height,
        padding: EdgeInsets.all(width * .02),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: width * .9,
                  height: height * .06,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(
                        MediaQuery.of(context).size.width * .02),
                    border: Border.all(color: Colors.grey[200]),
                    color: Colors.white,
                  ),
                  // padding: ,
                  child: TextField(
                    // controller: widget.controller,

                    // maxLength: widget.number == true ? 8 : 40,
                    style: labelTextStyle.copyWith(
                        // color: secondaryColor,
                        fontSize: 20,
                        color: Colors.black,
                        fontWeight: FontWeight.normal),

                    decoration: InputDecoration(
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.all(width * .03),
                        counterText: "",
                        hintText: "Search Property",
                        suffixIcon: InkWell(
                          splashColor: white,
                          onTap: () {},
                          child: Container(
                            width: width * .12,
                            height: height * .04,
                            decoration: BoxDecoration(
                                borderRadius:
                                    BorderRadius.circular(width * .03),
                                color: mainColor),
                            child: Center(
                              child: Icon(
                                Icons.search,
                                color: white,
                              ),
                            ),
                          ),
                        ),
                        // labelText: "${widget.title}",
                        hintStyle: headingStyle.copyWith(
                            color: Colors.black,
                            fontSize: 16,
                            fontWeight: FontWeight.w300)),
                  ),
                )
              ],
            ),
            SizedBox(
              height: height * .03,
            ),
            Expanded(child: ListView.builder(itemBuilder: (context, int index) {
              return PropertyCard();
            }))
          ],
        ),
      ),
    );
  }
}
