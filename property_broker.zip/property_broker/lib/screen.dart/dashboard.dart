import 'package:bezier_chart/bezier_chart.dart';
import 'package:fl_chart/fl_chart.dart' as prefix;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:multi_charts/multi_charts.dart';
import 'package:property_broker/utils/colors.dart';
import 'package:property_broker/utils/textstyle.dart';
import 'package:property_broker/widgets/customAppbar.dart';
import 'package:property_broker/widgets/customdrawer.dart';

class DashBoard extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _DashBoard();
  }
}

class _DashBoard extends State<DashBoard> {
  var width, height;
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  final fromDate = DateTime(2018, 11, 22);
  final toDate = DateTime.now();

  final date1 = DateTime.now().subtract(Duration(days: 2));
  final date2 = DateTime.now().subtract(Duration(days: 3));

  final date3 = DateTime.now().subtract(Duration(days: 35));
  final date4 = DateTime.now().subtract(Duration(days: 36));

  final date5 = DateTime.now().subtract(Duration(days: 65));
  final date6 = DateTime.now().subtract(Duration(days: 64));
  @override
  Widget build(BuildContext context) {
    width = MediaQuery.of(context).size.width;
    height = MediaQuery.of(context).size.height;
    // TODO: implement build
    return Scaffold(
      key: scaffoldKey,
      drawer: BuyerDrawer(),
      backgroundColor: white,
      appBar: CustomAppBar(
        height: height * .08,
        title: "Dashboard",
        appointment: false,
        support: false,
        width: width,
        home: true,
      ),
      body: Container(
        width: width,
        // height: height,
        padding: EdgeInsets.all(width * .03),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Row(
                children: [
                  Text(
                    "Publications",
                    style: headingStyle.copyWith(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black),
                  )
                ],
              ),
              SizedBox(
                height: height * .05,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: width * .6,
                    height: height * .15,
                    child: PieChart(
                      showLegend: false,
                      values: [15, 70, 20],
                      // labels: ["Label1", "Label2", "Label3", "Label4", "Label5"],
                      sliceFillColors: [
                        Colors.orange,
                        Colors.red,
                        Colors.teal[700],
                      ],
                      animationDuration: Duration(milliseconds: 1500),
                      legendPosition: LegendPosition.Right,
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                children: [
                  Text(
                    "Listing Type",
                    style: headingStyle.copyWith(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black),
                  )
                ],
              ),
              SizedBox(
                height: height * .02,
              ),
              bottomOptions(),
              SizedBox(
                height: height * .03,
              ),
              Row(
                children: [
                  Text(
                    "Top Leads",
                    style: headingStyle.copyWith(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black),
                  )
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                children: [
                  Text(
                    "Sale",
                    style: headingStyle.copyWith(
                        fontSize: height * .015, color: Colors.grey),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: width * .02),
                    width: width * .04,
                    height: height * .04,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle, color: Colors.blue),
                  ),
                  SizedBox(
                    width: width * .03,
                  ),
                  Text(
                    "Rent",
                    style: headingStyle.copyWith(
                        fontSize: height * .015, color: Colors.grey),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: width * .02),
                    width: width * .04,
                    height: height * .04,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle, color: Colors.purple),
                  ),
                ],
              ),
              SizedBox(
                height: height * .03,
              ),
              Row(
                // mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: EdgeInsets.all(width * .02),
                    width: width * .92,
                    height: height * .4,
                    child: BezierChart(
                      bezierChartScale: BezierChartScale.MONTHLY,
                      fromDate: fromDate,
                      toDate: toDate,
                      selectedDate: toDate,
                      series: [
                        BezierLine(
                          label: "Rent",
                          lineColor: Colors.purple,
                          onMissingValue: (dateTime) {
                            if (dateTime.year.isEven) {
                              return 20.0;
                            }
                            return 5.0;
                          },
                          data: [
                            DataPoint<DateTime>(value: 10, xAxis: date1),
                            DataPoint<DateTime>(value: 100, xAxis: date2),
                            DataPoint<DateTime>(value: 200, xAxis: date3),
                            DataPoint<DateTime>(value: 0, xAxis: date4),
                            DataPoint<DateTime>(value: 10, xAxis: date5),
                            DataPoint<DateTime>(value: 47, xAxis: date6),
                          ],
                        ),
                        BezierLine(
                          label: "Sale",
                          lineColor: Colors.blue,
                          onMissingValue: (dateTime) {
                            if (dateTime.month.isEven) {
                              return 10.0;
                            }
                            return 3.0;
                          },
                          data: [
                            DataPoint<DateTime>(value: 20, xAxis: date1),
                            DataPoint<DateTime>(value: 100, xAxis: date2),
                            DataPoint<DateTime>(value: 150, xAxis: date3),
                            DataPoint<DateTime>(value: 30, xAxis: date4),
                            DataPoint<DateTime>(value: 45, xAxis: date5),
                            DataPoint<DateTime>(value: 45, xAxis: date6),
                          ],
                        ),
                      ],
                      config: BezierChartConfig(
                        displayYAxis: true,
                        stepsYAxis: 20,
                        updatePositionOnTap: true,
                        showDataPoints: true,
                        verticalLineFullHeight: true,
                        backgroundColor: Colors.white,
                        verticalIndicatorStrokeWidth: 3.0,
                        displayLinesXAxis: true,
                        xAxisTextStyle: headingStyle.copyWith(
                            fontSize: 10, color: Colors.black),
                        yAxisTextStyle: headingStyle.copyWith(
                            fontSize: 10, color: Colors.black),
                        verticalIndicatorColor: Colors.black26,
                        showVerticalIndicator: true,
                        verticalIndicatorFixedPosition: true,
                        backgroundGradient: LinearGradient(
                          colors: [
                            Colors.white,
                            Colors.white,
                          ],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        ),
                        footerHeight: height * .08,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget bottomOptions() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Text(
          "Sale: 4",
          style: headingStyle.copyWith(
              fontSize: height * .015, color: Colors.grey),
        ),
        Container(
          margin: EdgeInsets.only(left: width * .01, right: width * .01),
          color: Colors.grey,
          height: height * .02,
          width: 1.5,
        ),
        Text(
          "Rent: 11",
          style: headingStyle.copyWith(
              fontSize: height * .015, color: Colors.grey),
        ),
        Container(
          margin: EdgeInsets.only(left: width * .01, right: width * .01),
          color: Colors.grey,
          height: height * .02,
          width: 1.5,
        ),
        Text(
          "Commercial Rent: 4",
          style: headingStyle.copyWith(
              fontSize: height * .015, color: Colors.grey),
        ),
        Container(
          margin: EdgeInsets.only(left: width * .01, right: width * .01),
          color: Colors.grey,
          height: height * .02,
          width: 1.5,
        ),
        Text(
          "Commercial Buy: 1",
          style: headingStyle.copyWith(
              fontSize: height * .015, color: Colors.grey),
        ),
      ],
    );
  }
}
