package com.example.property_broker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
